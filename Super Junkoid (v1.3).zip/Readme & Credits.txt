____________________________________________________________________________

SUPER JUNKOID (Version 1.3 - 2023)
by P. Yoshi
____________________________________________________________________________

You can save your progress at any Hot Springs by stepping on the attached altar.



____________________________________________________________________________

INSTALLATION
____________________________________________________________________________

Use an IPS Patcher (such as Lunar IPS), and...
Apply "Super Junkoid 1.3.ips" to "Super Metroid (JU) [!].smc" (3,072KB)


____________________________________________________________________________

CREDITS
____________________________________________________________________________

▼Design, Art & Gameplay
P. Yoshi


▼ASM & Patches
Amoeba
Benox50
BigDomino
Black Falcon
Crashtour99
JAM
Kejardon
Moehr
Nodever2
Oi27
OmegaDragnet9
P. Yoshi
PHOSPHOTiDYL
PJBoy
Quote58
SMILEuser96
Sadiztyk Fish
Scyzer
Silver Skree
Smiley
TestRunner
Tundain
caauyjdp
dewhi100
mccad00
person701


▼Music
Albert V.
Kottpower
Metaquarius
SUPERMETROIDFTP



Created with SMART 1.19 (Amoeba & Testrunner)
SpriteSomething (Artheau & Mike Trethewey)
YY-CHR (Yy, Yorn)



