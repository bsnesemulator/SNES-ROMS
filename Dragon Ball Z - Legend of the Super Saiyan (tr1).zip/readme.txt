               ************************************
               *                                  *
               *         Klepto Software          *
               *                                  *
               ************************************
               *      http://klepto.s5.com        *
               ************************************
                            PRESENTS

     Dragon Ball Z: Legend of the Saiyans English Patch v.95


By:  SirYoink (revdpimp@geocities.com)

95% complete

DO NOT apply this patch to your only copy of the ROM.  Keep a copy of
the original, as future patches must be applied to the original ROM.

_What the patch does_
English fonts.  A new font should be implemented in the final version.
99% of menus translated.
95% of dialogue translated.
80% of names expanded.
100% of intro translated.
80% of bug testing complete.

_Applying a patch_
For instructions on using this patch, read my FAQ online at:
http://klepto.s5.com/ips/ipsfaq.html

_About this translation_
This translation is not yet complete.  Don't be surprised if you see
Japanese in the untranslated parts.

_Thanks to_
Darkforce, MO, Jair, BessaB, and everyone else who so much as lifted a
finger to help translate this game.

_Disclaimer_
Its just a ROM patch, but just as a precaution, you use this at your
own risk.  So if you @#$% something up, you can't blame me, k?