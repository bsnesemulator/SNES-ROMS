Hello! Thank you for downloading Sicari Remastered. It's somehow been three years since I originally released this hack. I think however it's time for a long awaited update! This isn't anything major, it doesn't add new levels or anything. It basically cleans up a few things I wasn't satisfied with! If you haven't played this before, I really hope that you enjoy it, since I put a lot of time into it!

CHANGES:
-Dry Bones now killable with throwable objects (for consistency with bony beetles)
-Moved several midway points around:
  -Nuclear Sewers, moved into second sublevel to take advantage of LM 3.0, and to make level more fair.
  -Little Nancy, moved closer to the boss door to make level more fair.
  -Redfang Yard, moved respawn location into second sublevel, courtesy of LM 3.0
  -Abandoned Factory, moved respawn location into second sublevel, courtesy of LM 3.0
  -Up the Walls, moved into second sublevel to take advantage of LM 3.0, and to make level more fair.
  -Central Tower, moved respawn location into second sublevel, courtesy of LM 3.0
-Ditsy riding segments:
  -One tile jumps have all been made easier by giving said platforms a wider hitbox, and thus hopefully a wider room for error.
  -Raised some of the ceilings in "Bloodied Wastes" so that it's harder to unknowingly bonk yourself to death.
-Several lines of dialogue have been rephrased to sound less awkward and more in character.
-Challenge houses can now be replayed as many times as you want, should you wish to farm lives.
-Fixed an error in "Surfin' Girl" where Sicari's decapitated head would still appear after being sliced, despite the fact decapitations should not be possible in said level.
-Fixed a small error with Gracie's sprite where one of her legs are transparent during her jumping animation.
-Pointless enemies:
   -Removed the poor Hostakke who would fall to his death in "Orenji City" before you could so much as reach him.
   -Moved the spinning spiny in "Redfang Yard" so that he's not killed by an explosion before he can attack you.
-Added an off-screen ceiling to "Gingerbread Land" to prevent players from simply flying over the level. Oops!
-Several other things I'm probably forgetting lol