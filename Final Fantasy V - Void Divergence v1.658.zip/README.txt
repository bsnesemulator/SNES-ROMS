Final Fantasy 5 - Void Divergence, v1.658
Praetarius



===Patching===

The patch is for an unheadered J ROM, use SNESutil or similar to remove an existing header.
NEVER patch over an older version of this hack, get a clean ROM!

English translation is already included.

You may need LunarIPS or similar to apply the patch.



===Emulator===

Will not work with ZSNES, SNES9x 2005 or earlier.



===Turn/MP System===

At the start of battle each of your character is reset to 10 MP; more with certain abilities or job levels.
Defending (command menu right) awards at least 100 MP (10%max + 90), though cannot surpass maxMP.
If a character's turn ends without defending and they have at least 100 MP
they automatically take another turn and lose 100 MP.
Brave (command menu left) grants the user (12.5%maxMP + 100) MP but makes them skip the next turn.
In essence, defending lets you take your turn later when it is more convenient.
A few more abilities allow you to manipulate turn order:
E.g. the Time spell Shift makes the target ally ready to act now, basically trading one character's turn for another,
and the ability !Brave allows the user to take two turns now but skips his next.
Feel free to combine these.

Furthermore MP damage that exceeds the current MP gets translated into a longer delay until the turn finally comes up.



===Cooldowns===

Items are not used up but are on a cooldown shared between all items (and item-like skills) per character.
For most items effect potency (more) and cooldown scales (less) with stack size.
Defending reduces remaining item cooldown.

!Abilities (except !Fight) that are neither item variants or skill menues tend to have higher power
but run on a shared skill cooldown; the exact value is affected by the STR stat.
Using brave reduces the remaining skill cooldown.



===Brave/Defend benefits===

In addition to getting more extra MP than from defending,
using brave gives +20 accuracy until the unit ends its chain of actions (try to defend or run out of MP)
and reduces remaining skill cooldown by about another turn.
After using brave you can't successfully enter the defending state, instead you just end your remaining turn and gain +100 MP.


Going into defense stance reduces remaining item cooldown by about 25%.
While defending a unit does not have elemental weaknesses against regular damage,
takes about 25% less damage (diminishing returns when stacked with buffs like armor/shell, etc.)
and less status damage.
Additionally once per battle if a unit would die from damage while defending it instead survives at 1 HP.



===Jobs===

Each job up has permanent effects on the characters.
Stats increase based on the job that has levelled up as well as one ability is gained.
Just switching to a job grants three abilities temporarily.

The ABP cost per job level depends on the total of gained job levels, however ABP are still gained for each job individually.
Transfering from one job to a different one regains half the current ABP.

The cap for job levels is 30 and increases to 70 in New Game Plus.

Every character has a unique setup of jobs they can use, each job is unusable on at least one character.
Jobless cannot be accessed once a job is chosen.



===Stats===

Strength
Influences equipment weight and skill cooldown.

Agility
Influences turn frequency, physical accuracy and physical evasion.

Vitality
Influences maximum health, status resistance and general damage reduction.

Magic
Influences maximum mana and magic accuracy.

Equipment weight
Reduces evasion, turn frequency and magic accuracy.



===Elements===

Almost every attack and status effect is associated with an element.
Likewise almost every piece of equipment has an elemental affinity.
Each element resists itself and one more element and has weaknesses to 2 elements.
The 3 relics a character has equipped determine that character's strength and weaknesses.
Shields increase resistance to their element by one step, weak -> neutral -> resistant -> very resistant
Weapons are not included with the defensive elements.
If a combination results in being both resistant and weak to one element it gets unified to a neutral state.

While a character is defending damage-inflicting attacks can not hit their weaknesses.

Status effects are influenced by the elemental strength and weaknesses as well;
e.g. it is harder to inflict a earth resistant target with petrification
while it would affect targets weak to earth much easier
and targets weak to poison take more damage from poison ticks.



===Field Effect===

The battle terrain holds 5 elemental icons, displayed above the enemy names in the UI in the bottom left.
For each matching icon strength of attacks, heals and status effect chance of that element is increased.
Every element has one element that opposes it which lowers the above effect,
the opposing element is always the element that also resists it (but is not the same), e.g. earth weakens lightning.

The 5 initial icons are based on the current battle location.

Every time an action is used that displays its name at the top, that action's element gets pushed unto the terrain elements
and removes the oldest one (the left-most icon).

In short:
1) use attacks that hit a weakness to increase your offense power via field elements
2) use the opposing element of your enemy to greatly reduce their power
3) stack a status effect's element to have a greater chance to bypass status immunities



===Field Combos===

After the world balance has been sufficiently shattered (2 crystals destroyed) it becomes possible for icons of certain kinds to combine into special icons;
this requires 2 of both to be on the field.
Some of those provide special effects while they are on the field, other effects my be triggered by "consuming" the icon, i.e. pushing it of the list by adding a new one.
Consume effects are not triggered by skills that replace the entire field.
Combination icons support the elements of their components but oppose nothing by default.

2 fire + 2 ice = 4 water
2 ice + 2 water = 4 ice
2 light + 2 poison = 4 void, reduce def by 5 each
2 fire + 2 light = 4 sun, removes swamp effect, dot vs undead units, heal user if consumed
2 wind + 2 earth = 4 diamond, exp gain +25% while on field, consume for 200 gold
2 ice + 2 wind = 4 snow, +5 atb delay per icon; can't get extra turn from 100 mp
2 wind + 2 void = 4 vacuum, massive dot
2 water + 2 earth = 4 poison, set swamp effect
2 bolt + 2 ice = 4 mana crystal, +2 mp gain per icon after turn, +50 mp if consumed
2 water + 2 wind = 4 (thunder)storm, accuracy down (-5 each), random chance to get thunderstruck
2 water + 2 bolt = -same-
2 bolt + 2 poison = 4 ? icons, +10% power buff, +1 icon creation
2 light + 2 void = "big bang", randomize all icons
2 fire + 2 poison = 4 moon, status chance gains randomness, consume to heal status damage



===Status Effects===

Nothing is truly immune to status effects, only the chance is affected.
Each status belongs to an element and the chance to inflict a status rises and falls with the effectiveness of that element.
After inflicting a status effect on a monster that monster gains increased resistance to that specific status effect.
For monster with multiple lives, those status resistances vanish after 1-2 deaths.
If remaining lives are odd, those of fire, ice, bolt and wind type are removed, else the rest.

Failing to inflict a status ailment instead inflicts status damage.
This status damage makes all status effects more likely to succeed.
This status damage is shared across all status effects and unique for each hero and monster.
Once a status ailment is inflicted, the status damage is reset to 0.

While moon icons are on the field the threshold for status randomness is lowered.
Without moon icons the damage needs to reach 80% (empty status bar) to have a random chance to succeed before 100% damage,
with icon present 30% status damage is the threshold when randomness sets in.



===Difficulty Selection===

Under the menu point "Config" you can adjust various settings.


Exp.Gain
Allows to switch off experience gain from battles. ABP, items and gold will still be awarded.



Encounter
How often random encounters happen with 6 as no encounter, 3 as vanilla rate and 1 is grind mode.
The rate itself is still random to an extend.



Challenge
How strong enemies actually are, 6 as lowest, 1 as highest.
Affects HP, damage, defense, speed, chance to land status effects.
On difficulty 1 bosses can drop a special Void Shard collectables which increase exp gain.



Job Set
Normal is the standard mode; you gain access to more jobs as you progress the plot
and each character can choose from those that are compatible with them, e.g. Bartz can never be a chemist.

Single gives you access to all jobs to choose from right at the start
but once a job is selected that is the only job for that character for the rest of the game.
Exp gain is increased, ABP gain is decreased and the max level for an individual job is increased from 5 to 15.
Jobs still only learn new abilities up to lv 5.

Job Set setting cannot be changed once any job (besides Freelancer) is chosen for a character.



Core Rules
Basic is the default mode.

Expert mode makes 6 changes to the game:
1) damage multiplier is truncated roughly like in vanilla (though at the end of the calculation rather than at the start)
2) enemies get [75..150]% damage variance
3) enemy stats (and rewards) scale up when the party is higher levelled than the enemy's base level
4) you cannot revive party members
5) battle is not auto-reset on game over
6) together with difficulty 1 Void Shard drop amount is doubled



=== Character Names ===

Hold L or R while entering the menu to open the character rename screen for the lead character (top slot).
Move a different character to the top most character slot to rename them.
This should affect all dialogs and menus.



=== New Game Plus ===

To transfer a savegame to the next new game plus cycle, hold L+R while loading the savegame.

Levels, job levels, items, magic and abilities are kept.
Names, plot items, chests and progression are reset.

The cap for job levels is increased from 30 to 70.

Strength of enemies is increased, some bosses may hold additional surprises.

Enemy strength can scale up to NG+15.



=== True Final Boss ===

Certain conditions unlock more of the final boss's power.

1) collect 40+ Void Shards
2) defeat Omega
3) defeat Shinryu
4) defeat Enuo



=== Misc. ===

You can hold any button to fast forward dialog, event pauses and spell animations a bit.

Battles are auto-reset on game over unless you play with expert rules or cancel the reset by holding the B button.






====================================
========== Mod Motivation ==========
====================================

Everything from here just details why this mod was made in such a way.
Feel free to skip this.



=== Character/Job limitations ===

One of my favorite things to do in RPGs is building "my team".
FF5 doesn't really allow that since you can just grind until everything is maxed out.
Plus that unrestricted job selection entirely disregards characterization.
Bartz is afraid of height why can he be a dragoon?
How can spoiled, anti-aggressive princess Lenna be a Berserker or a Thief?
How can our resident amnesiac Galuf remember enough to cast spells as any mage job?
And pirate queen Faris acting like a self-sacrificing knight makes not much sense either.
Admittedly I couldn't follow through on every plot restriction or there'd be too few jobs available.

Next point is how little influence experience in other jobs meant.
Spent half the game as a Black Mage and then switched to a knight without taking Black as an ability?
Congratz, you've basically just successfully denied half your life as if it didn't happen.
So I went and made it so you gain at least a few stat points for it,
making the knight in this example a character with a much higher magic stat than otherwise.
Plus giving innate abilities for any job, I mean why does it matter to my ability to learn Blue magic
whether I wear a blue tunic from the Freelancer job or the green tunic from the ranger job?



=== Turn/MP System ===

At first I wanted to scrap MP entirely.
It is a system done to death, especially when it has lost its entire meaning with gigantic MP pools and
MP restorative items as easily available as drinking water.
Doesn't work out too well once you remember that tiered magic exists.
Or how impossible it would be to balance a cost-free death spell to regular damage spells.
Then I encountered Bravely Default and a few tactics games that used action points with varying cost by action.
Considering how BD seems to me like a stealth remake of FF5 going full cycle on that idea seemed like a natural choice.



=== Elements ===

FF5 has 8 regular elements but many enemies have either no weakness at all or only to one for which you've barely any access.
Outside of region-locked Gaia you've only access to TWO water attacks in the entire game: the Leviatan summon and water scrolls. (Aqua Rake is non-elemental)
Not that you have access to them for half the bosses that actually do have a weakness to water (ifrit).
Poison doesn't fare better with just Bio or holy elemental with Holy and very few weapons - most at the very end of the game.
And there's nonsense like being immune to poison damage but still being able to be poisoned.
A 180 turn was in order: EVERYTHING gets an element so weaknesses can matter again.
Also status effects were tied to those elements for those same reasons:
a being weak to poison damage should also be weak to poison tick damage.



=== SNES vs GBA ===

In my opinion the GBA version lost a great deal of charm compared to the SNES version.
Plus the additional content doesn't help much:
4 new jobs doesn't matter when you don't get them until the game is done and/or you've already capped out your job limit.



=== Title ===

Almost everything is different, i.e. divergent from the original, even things that amount to "nothing".
Plus, void is everything in the plot, means it exists not.



=== High Power Level ===

This is meant in the sense that status effects work on "everything", late game bosses still have weaknesses
and most skills still remain useful throughout the game instead of bombarding the player with a new, better skill every 2 minutes.
And so on.

If Mix/Dragon Power (target gets +20 levels, capped at 255, usable on everything with NO save),
the old status (reduces level every couple seconds), e.g. via Blue/L2 Old, and Blue/L5 Death exist
everything is killable in less than a dozen "attacks", even if it has 1.000.000.000.000 HP and is immune to *everything* three times over.
This invaldiates the meaning of commonplace-normal, boring "balance", i.e. status effects being useless and free full heals existing.



=== Bravely Default a FF5 stealth remake? ===

Not really but there are a few too many coincidentally parallels.
Tiz = Bartz
bland main character ending on a z, only later shoehorned in as somehow not irrelevant to the plot

Agnes = Lenna
the girl trying to save the crystals, setting the whole plot in motion.
Both have a problem to accept the world as the cruel place it is.

Edea = Faris
initially (very shortly) disguised princess or equivalent of the local kingdoms/dutchy involved with the crystals.
Both have their father die saving the crystals from the bad guy.

Ringabel = Galuf
Amnesiac with very convenient sudden insights, not from this world. Both have their original world destroyed.
Also "both" die during the game failing to stop the bad guy, though in Ringabels case it was the native copy of him, not the party member.
Gameplay wise it doesn't even matter in both cases; FF5 gives you a (mostly) stat identical copy to continue while BD has your guy continue to exist.


The four crystals are present, malfunctioning and even visited in the same order (wind, water, fire, earth).

The first air vehicle is in both cases gotten after beating four bosses:
Barras, Holly, Ominas, Heinkel or
WingRaptor, Karlabos, Siren, Magissa (Forza is optional)
Said vehicle is already unusable one crystal/set of jobs later, and takes it away after the next best dungeon by plot or geographic.

And then something about multiple worlds getting destroyed because the main party is incompetant and lets the BBEG get his way multiple times.