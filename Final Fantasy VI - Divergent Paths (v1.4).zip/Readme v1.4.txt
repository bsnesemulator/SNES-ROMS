Title: Final Fantasy VI: Divergent Paths
Author: PowerPanda
Version: 1.4
Applies to: FF3us v1.0

Contents:	DivergentPaths_Header_1.4.ips - Applies changes to a headered 1.0 rom
		DivergentPaths_NoHeader_1.4.ips - Applies changes to an unheadered 1.0 rom
		FFVI Divergent Paths Manual.pdf - The game manual
		EXTRAS Folder - Contains a save file archive, an SPC of the new song, and a patch for editor compatibility
		SPOILERS Folder - Contains mini-guides of portions of the game that are not found in standard walkthroughs

--------------------------------------------------------------------------------
-=Intro=-

Another day, another Final Fantasy VI hack. Why should Divergent Paths be any different than the others?

Divergent Paths is, at its heart, a re-arrangement of the story of Final Fantasy VI. Many people forget what games were like in the 90s. When Squaresoft released FFVI, they had no idea that it would become one of the most beloved games of all time. They had just one year to make the game and get it out the door, and there is evidence in the code that the production schedule got the better of them. Adding the final layer of polish to the story... re-arranging content to flow better and enhance character development... such things were not possible.

The inspiration for Divergent Paths comes from another famous 90s JRPG, Lunar: The Silver Star. When the game was ported from Sega CD to Sega Saturn, the original development team was given a chance to not just port it, but revise it. They took the opportunity to fix what they thought the two most glaring parts of the story were: Luna's lack of presence. So, when they came to the scene where Luna bids farewell to Alex and Ramus at the dock, they rewrote the scene to have her jump aboard the boat at the last moment. From that one small change, much of the rest of the plot fell into place.

What changes would be made to Final Fantasy VI if Squaresoft had been given the same chance? Divergent Paths is the answer to that question (1). It begins with a simple change. Edgar, reunited with his brother after years apart, sees Sabin knocked off the raft, floating down the river. He doesn't wave goodbye... he does what any sane brother would do: jumps in after him! Thus begins a series of small changes to the familiar events of FFVI that make each beat of the story more in service of its beloved characters (2). The small changes cascade upon each other, peaking with a very different series of events in Thamasa. Everyone's favorite general survives the attack, and is given a chance at redemption. Even in the World of Ruin, the echoes of the events are still felt, leading to several changes that close off many characters' arcs in a more satisfying way.

Leo surviving in Thamasa will immediately draw comparisons to the famous "General Leo Edition". Divergent Paths owes a debt of gratitude to this earlier mod. FedoraJoe showed that the best way to get Leo on your team was not to revive him, but to change events to keep him alive. However, Divergent Paths has several key differences. First, no characters are demoted to guest status. Leo is added as a fully-playable 15th character, and Shadow remains playable. There's even a 16th character hidden somewhere in the World of Ruin, allowing for a complete roster.

Second, Leo has a fully fleshed-out character arc that is interwoven with other characters. By repurposing existing content that was not tied to any specific character (like the Wounded Soldier sidequest), and stitching it together with a handful of brand new key scenes, Leo becomes as central to the plot as any other main character. 

While story is the main purpose of Divergent Paths, it is not the only change. In addition to the added playable characters, it includes almost every bugfix released, and utilizes dozens of other small improvements made by the community to make the game play smoother than ever before. This includes 1 new Esper, 10 new spells (3), and a lower random encounter rate to smooth out the pacing and keep the players on their toes without altering the base difficulty of the game (4). Divergent Paths even includes a new song, composed by William Kage, to add to the soundtrack. Each change has been tested wholistically with all of the others to ensure that it never stops feeling like the Final Fantasy VI that you know and love5.
Power Panda

(1) Many of the storyline changes are taken from dummied lines, cut scenes, interviews with developers, and even the little-known doujinshi novel written by Soraya Saga.
(2) A demo of this hack was released in Oct 2017, covering just the 3-scenario section of the game. This demo was well-received by the community, and has been incorporated into several other hacks, including being an optional choice for the Beyond Chaos randomizer.
(3) The new esper, Leviathan, and 2 of the spells, Flood and Grav 3, were taken from the GBA remake. The other 8 spells are borrowed from other Final Fantasy titles. In order to make these possible and allow an additional magic list for Leo, two concesssions were made: Players can no longer learn magic from shields, and all characters use the same desperation attack.
(4) There has been one slight system rebalance though. The encounter rate has been dropped by 25%, and the Espers have been given better levelup bonuses. This causes your characters to grow slightly more slowly, offering a mild challenge, and allowing you to specialize each character more, all the while cutting down on tedium. If you wish to train your characters more quickly, talk to the Moogle in the training school for tips on modifying the encounter rate.

--------------------------------------------------------------------------------
-=Patching Instructions=-

Divergent Paths is a patch made to the original Super Nintendo Game, and is not compatible with either the GBA Remake, the Mobile Port, or the Steam Version. There are no plans to port the changes over, as the versions do not share source code.

To apply the patch, you will need an original copy of the rom (version 1.0), the IPS Patch included in this download, and an IPS Patching program, such as Lunar IPS. Follow the instructions in whichever program you use to apply the patch to the rom.
The difference between the headered version and the unheadered version has to do with where the code resides within the rom. You can use the program available online entitled “ROM Hasher” to find out if your rom has a header or not. You can also use the program “SNES Rom Utility” to add or remove one. 

If this is over your head, simply apply the “DivergentPaths_Header.ips” to a copy of your Rom. If the game crashes when you try to load it, then you need the “NoHeader” version. If it plays fine until the first battle, but then it freezes, you have version 1.1 of the rom, and you need to find or dump a 1.0 version.

Divergent Paths does not expand the original rom, so it should be compatible with flashcarts and repro carts, being able to be played on a real Super Nintendo. It has been tested on ZSNES, SNES9x, and BSNES to ensure as high of compatibility as possible. This manual is also sized to fit the SNES box, should you choose to print it.

--------------------------------------------------------------------------------
-=Version 1.4 Fixes=-

MAJOR FIXES
* At high levels, the Gauntlet, Bracers, Earrings, Atlas Armlet, and Hero Ring could cause your damage to temporarily exceed 16-bit calculations, resulting in you doing fractional damage. This is a vanilla bug I was unaware of. I have applied Drakkhen's "Physical Damage Overflow Fix" to correct this. This older patch was applied instead of the newer "Ultimate Damage Fix" patch to maintain compatibility with other changes that I have made in Divergent Paths. Thanks, Rubicant, for finding this. With this calculation fixed, it is now possible to give 2-Hand and Dual flags to the Atma Weapon.
* In the World of Ruin, if you recruited Cyan before Leo, there would be a softlock when recruiting Leo. This was fixed.
* In the Auction House, if you bid on Golem, but didn't have enough money, there would be a softlock. This was also fixed.

MINOR FIXES
* Ragnarok's levelup bonus has been corrected to be "MP+50%", rather than a copy of Odin's "Speed+2".
* Purchasing Sraphim now correctly subtracts 3000 GP, rather than 10 GP.
* In Terra's scenario, the scene where Gau makes Banon lose 500 GP did not finish correctly if you had less than 500 GP. This scene has been rewritten so that you lose no money. Banon, as a guest character, has his own money source.

IMPROVEMENTS
* Sketch now uses the caster's stats, instead of the monster's.
* Control continues to use the monster's stats, but upon successful control, the caster will get an immediate free turn.

ANIMATION CHANGES
Thanks to DrakeyC, we now have a list of all weapon animations. He uncovered 2 unused weapon animations, and I discovered that I had unintentionally dummied out a 3rd when I changed the animation for the Thunderblade. The following animation changes have been made:
* Enhancer now uses Thunderblade's original animation.
* Rune Edge uses a previously unused sword graphic and animation.
* Gau's Master Fist was renamed to "Pummel Fist" uses a previously unused attack animation, similar to the Pummel rage from the original game.
* The "Limit" attack that sometimes triggers at low health has been changed from the Pummel animation to Riot Blade, Terra's original Desperation Attack.

-=Version 1.3 Fixes=-
MAJOR FIXES
* On all previous versions, adding Setzer to the roster for the final battle would cause a softlock after you beat Kefka. The source of this bug has been found and fixed, thanks to rhonryderz!
* If you have unlocked the ending where Shadow doesn't die, he will now appear on the Falcon's deck during the ending cutscene.

-=Version 1.2 Fixes=-
MAJOR FIXES
* The calculation for Desperation Attacks (Limit) has been corrected, so that they will only occur 25% of the time when you are low on health. The 2nd DA (LimitBreak) that some of you found is still in the game, but it is much harder to trigger.

MINOR FIXES
* Opera Lyrics don't run over if you fail to make a selection for the 3rd stanza.
* Celes does not sometimes get stuck facing left in the Razing of Vector intro scene.
* The Ultros fight in the Espers Cave (Relm's intro) plays boss music, and not the normal battle music. This is a bug from vanilla.
* Banon doesn't start KOed if Kamog falls in the Moogle Battle.

-=Version 1.1 Fixes=-

MAJOR FIXES
* The breakable tools had 2 bugs. The first was that their actual rate of breakage was 1 in 8. This has been changed to 1 in 32. The second was that using Tools 12 or more times in a battle could cause the item buffer to overflow, adding garbage items to your inventory, and causing any Tools used after that (even unbreakable tools) to be removed from your inventory. This was discovered to actually be a bug in the vanilla game that had a very low chance of occurring. Thanks to a herculean effort involving Subtraction, Gi Nattak, Serity, Seibaby, Bropedio, SirNewtonFig, and especially C-Dude, this bug has been resolved.

SOFTLOCK FIXES
* Setzer's Letter in Owzer's House respawned, causing a softlock if you read it without Locke and Celes in your party. This has been resolved.
* Depending on your party makeup, the Fanatics' Tower Roof had a despawned NPC (The Magimaster), which could lead to a softlock. The NPCs have been shifted around so that if an NPC needs to be despawned, it is an NPC of little consequence.

MINOR FIXES
* All single-enemy formations have had "Pincer Attack" disabled.
* There was 1 tile in the Doma Military Camp that could cause your character to get stuck. This has been corrected.
* A few small typos were fixed as they were reported.

OTHER CHANGES
* Banon's Chocobo Riding sprite was edited by SilentEnigma to include more consistent shading.
* The Auction House in the World of Ruin has better items. You can buy one set of Marvel Shoes for 50000 GP, and as many Hero Rings as you would like for 10000 GP.
* It is now possible to rare steal a Cat Hood from a Pug.

--------------------------------------------------------------------------------
-=Further Information=-

Please check the included PDF manual for even more info about the game!