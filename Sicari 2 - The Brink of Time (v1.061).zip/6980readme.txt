~~~~~~~~~~~~~~~~~~~~~~~~~~

1.01
-Addressed issue in which starting from the midway point of "Redshift" would not enable vertical scroll.

~~~~~~~~~~~~~~~~~~~~~~~~~~

1.02
-Addressed issue in which starting from midway point of "Life's a Witch" could kill the player.
-Grammar fix in credits

~~~~~~~~~~~~~~~~~~~~~~~~~~

1.04
-Addressed issue where a game over would undo the clear event for "The Hungry Sand."
-Added some lives in "The Brink of Time" before the cutscene.
-Ammended some names in credits.

~~~~~~~~~~~~~~~~~~~~~~~~~~

1.05
-Addressed major issue in "Sergeant Bolts", in which the player could bar their own progression under specific circumstances.
-Minor level design adjustments to "Paradise City".
-Disabled pausing in intro level.

~~~~~~~~~~~~~~~~~~~~~~~~~~

1.06
-Adjustments to final boss
  -There are now new telegraphs for certain attacks
  -Boss will no longer occasionally get stuck
  -A checkpoint will activate upon phase 2, so that players do not need to fight the boss from the beginning.
  -Updated exAnimation.
-Corrected minor typos.
-Reduced SRAM size.
-Lives now save upon reset.
  -Old save files are compatible, although it is advised that you back them up before playing this new update. For old saves, lives will default to 1 upon load, but any additional lives will be saved.
-Anna is now playable in the bonus areas of her respective levels.
-Added a room after the post credits cutscene in which the player can talk to the characters.
-After clearing "The Brink of Time", markers will appear on the map to signify which levels have switch tokens. These markers will disappear after unlocking special world.
-Switch tokens will now become greyed out after you have collected them.

-Silence in the Library:
  -Added a midway point.
  -Added collectable diamonds.
-Oil Spill:
  -Adjusted secret exit to be more intuitive.
-Oh Ship:
  -Replaced the song.
-Paradise City:
  -Adjusted some of the enemies.
-Cowering Night: 
  -Adjusted spotlight colours to aid with visibility.
-Redshift:
  -Fixed glitchy visuals that occurred when playing on hardware.
-Temporal Shift
  -Shortened two jumps in the latter half of the level.
  -Lowered the teleport ceiling during second fire chase by 1 block.
  -Added decorative flames to the pit you jump out of following the second fire chase.
-Cosmic Apex:
  -Corrected animation on hopping flames in the final room.
-Other minor level design changes.