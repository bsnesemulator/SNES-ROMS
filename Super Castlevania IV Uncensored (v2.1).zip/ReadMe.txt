--------------------------------------

SUPER CASTLEVANIA IV UNCENSORED

--------------------------------------

CREDITS:


* RedGuy:

Creator of the Super Castlevania IV Editor (SC4Ed for short).
Without his breakdown of the game (including decompression and pointer changes), this hack wouldn't be possible.


* DarkSamus993:

Contributions and hacking wizardry.
Some tidbit here and there about how to rework tilemaps.


* Minucce:

Title screen Blood drop implementation from the Japanese ROM into the US ROM, and SPC decompression for inclusion of the Chain Whip SFX variants.


* ShadowOne333:

General hacking and de-censoring of the game's assets, as well as graphics for the new title screen, tilemapping and optional patches.


------------------------------------------

Patches included in this pack:


a) Super Castlevania IV Uncensored (Header).ips
Apply this patch to a HEADERED ROM with the following checksums to enjoy SC4 Uncensored:

CRC32: F5B68D68
MD5: 8167A0EADDFC50C4CE8A0698F8383801
SHA-1: 3384BB9DD2FFB4B6D33A1F53D10F567AA4d5264B
SHA-256: CC8FE76A5F5E8197D1564CFF47822531FD5107577B2243D8F785A7EB02A74AE9


b) Super Castlevania IV Uncensored (Headerless).ips
Apply this patch to an UNHEADERED ROM with the following checksums to enjoy SC4 Uncensored:

CRC32: B64FFB12
MD5: 094F035993E9724647B61DDCBA1E9A7A
SHA-1: 684C1DFAFF8E5999422C24D48054D96BB12DA2F4
SHA-256: 0EF6F4CCE5A2273FA49FE1CE724E0048A8E39C91DA6B00DBB693FE1BA909177D


c) Optional patches:

	* US Font (Optional patches)
		Apply this patch to an ALREADY PATCHED ROM of Super Castlevania IV to change the font style to use the original English font used in the English release in the game (if you don't like the Japanese style font).
		For a headered ROM, apply the "US Font (Header).ips" patch to an ALREADY PATCHED HEADERED ROM.
		For an unheadered ROM, apply the "US Font (Headerless).ips" patch to an ALREADY PATCHED UNHEADERED ROM.

	* Chain Whip US SFX (Optional patches)
		Apply this patch to an ALREADY PATCHED ROM of Super Castlevania IV to change the chain whip's sound effects (SFX) used in the English release in the game (if you don't like the Japanese chain whip sounds).
		For a headered ROM, apply the "Chain Whip US SFX (Header).ips" patch to an ALREADY PATCHED HEADERED ROM.
		For an unheadered ROM, apply the "Chain Whip US SFX (Headerless).ips" patch to an ALREADY PATCHED UNHEADERED ROM.

	* US Title Screen (Optional patches)
		Apply this patch to an ALREADY PATCHED ROM of Super Castlevania IV to change the blood-dripping title screen back to that of the original English/US release.
		For a headered ROM, apply the "Original US Title Screen (Header).ips" patch to an ALREADY PATCHED HEADERED ROM.
		For an unheadered ROM, apply the "Original US Title Screen (Headerless).ips" patch to an ALREADY PATCHED UNHEADERED ROM.
