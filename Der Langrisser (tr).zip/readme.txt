------------------------------------------------------------------------------
 Der Langrisser English Patch                                    version 1.02
 Written by DL Team                                            Copyright 2008
 Released on April 1, 2008                      http://projects.elsallia.com/
------------------------------------------------------------------------------
 
 WARNING
 
 At the time of this release, bsnes and SNESGT are the only Super Nintendo
 Entertainment System (SNES) emulator capable of playing Der Langrisser.
 Both ZSNES and SNES9x contain flaws in their sound emulation engines that
 will cause Der Langrisser to sporadically slow down and lock up during
 gameplay. These crashes occur roughly every half hour, and use of fast
 forward features will exacerbate this problem.
 
 Once this bug is triggered, the game will lock completely. It is impossible
 to recover, and you will lose all unsaved progress.
 
 For ZSNES users, a known fix is to disable "Stereo Sound" through the sound
 configuration window. There is no known workaround for SNES9x.
 
 The player hereby understands he is using these emulators at his own risk.
 As an aside, the alternative emulators SNEeSe and SNESGT may be capable of
 playing Der Langrisser, but they remain untested!
 
 Der Langrisser has been tested on actual SNES hardware, and is verified to
 function correctly. If you have access to a flash cart or console copier,
 this is undoubtedly the best way to experience the game.
 
------------------------------------------------------------------------------
 
 CHANGES
 
 1.02 - Rewrote a considerable amount of dialogue; reworded several lines
        which were translated based on faulty assumptions of who the speaker
        was; corrected a bug in the original game which caused Lana's injured
        portrait to appear in the end of Scenario 35; corrected a bug in the
        original game which listed Elementals as hireable units; enabled the
        dummied out class Demons as a hireable unit for Living Armour.
 
 1.01 - Corrected a formatting error that rendered Scenario 27 unplayable.
 
 1.00 - Initial release
 
------------------------------------------------------------------------------
 
 INTRODUCTION
 
 This patch is the result of a six-year long effort to translate
 Der Langrisser. It is not affiliated with Warui Toransu, and its only
 connection to No-Life Translations is through its members and the gracious
 donation of the mostly-complete "Light Path" script. This is a new
 translation and not an update to any existing project.
 
 For game play information, please read dermanual.pdf. High-resolution
 versions suitable for large screens and printing are available from the
 main website of this translation project.
 
 Players who require an Adobe Acrobat PDF viewer can obtain one from
 http://adobe.com/. Ubuntu Linux users can install Evince through
 Add/Remove Programs if they do not have it installed already.
 
------------------------------------------------------------------------------
 
 APPLYING THE PATCH
 
 This patch file is distributed in UPS format. You will need a UPS patcher
 to use it. byuu has released UPS patchers built for Linux and Windows at
 his Web site http://byuu.org/. The patcher is open source, and it should be
 easy for someone to prepare an OS X-based patcher.
 
 Start UPS and select your Der Langrisser V1.1 (J) ROM as the Input File. It
 must have a file size of 2,097,152 bytes. If you have a different file size,
 it means your ROM has a header. If you do not remove the header, then the
 patch cannot be applied.
 
 Output File can be any file you wish to write to. You must select the
 supplied dl.ups file as your Patch File. Click "Apply" and your translated
 copy of Der Langrisser will be created.
 
------------------------------------------------------------------------------
 
 CHEAT FILES
 
 Two cheat files are supplied for bsnes and ZSNES. The cheats contained in
 the files are enabled by default. Using the cheats will enable a debug-mode
 similar to the one present in Langrisser II for the Sega Megadrive.
 
 Commanders may be moved an infinite number of times and to any tile, units
 may attack any tile on the map or cast spells on any tile, magic and summon
 spells carry a 0MP penalty and any commander or unit may cast any spell.
 
 These codes are supplied to aid players in testing the game and triggering
 events which may otherwise never happen. Be warned that some very odd
 behavior can result from debug game play.

 We will consider repairing bugs which occur in only the English version of
 the game. You must demonstrate that any bug report is unique to our
 translation. We will ignore all reports that do not confirm the uniqueness
 of the bug.
 
------------------------------------------------------------------------------
 
 LICENSE
 
 This translation is licensed under the Creative Commons Deed as:
 Attribution-NonCommercial-NoDerivs 3.0 Unported.
 
 You are free to share, copy, distribute and transmit the work under the
 following conditions:
 
 * Attribution
   You must attribute the work to DL Team and include a link to the
   translation's website.
 
 * Noncommercial
   You may not use this work for commercial purposes.
 
 * No Derivative Works
   You may not alter, transform, or build upon this work. Especially for
   translation of this work into another language.
 
 For a copy of the Creative Commons Deed by-nc-nd 3.0, please visit
 http://creativecommons.org/licenses/by-nc-nd/3.0/.
 
------------------------------------------------------------------------------


