Yoshi's Strange Quest V1.3 - Yoshifanatic (aka yoshifanatic1, BiggestYoshifan)


====Story Summery====
This is the sequel to Mario's Strange Quest. Picking up where Mario's Strange Quest left off, it turns out that the part where Yoshi's eggs hatched at the end of MSQ didn't actually happen. What really happened after Mario beat Bowser, rescued Yoshi's eggs, and saved the princess was that Yoshi and his sleepy friend decided to move to a new land so that he can protect his eggs from Bowser before they really hatched. So, both Yoshis do so and they find themselves in the land of Weirdonia. However, it seems that Bowser apparently insists on stealing Yoshi's eggs, since Yoshi's eggs were stolen again while Yoshi was out shopping. Since Mario isn't around to help this time, Yoshi goes on a quest by himself to retrieve his eggs. However, just like Mario's Strange Quest, this isn't your ordinary quest. The land of Weirdonia is a strange land filled with bizarre gimmicks, weird themes, and possibly jelly filled donuts and pizza. Expect the unexpected during Yoshi's journey.


====YSQ's features====
- 71 levels (100 exits)
- Custom Graphics
- Tested on a real SNES
- Custom Music
- Custom ASM
- Lots of level variety
- Plenty of (possibly) unique gimmicks and themes
- Extraneous artwork done specifically for this hack, such as a box art image. You can find the general artwork here: http://biggestyoshifan.deviantart.com/gallery/33006643 and the drawings for the scenario rooms here: http://biggestyoshifan.deviantart.com/gallery/39779130. Note: Yoshifanatic plans on doing more YSQ art in the future.
- Lots of silliness and general weirdness
- A box art image, a cartridge sticker image, and a game manual, since real SNES games come with these things
- Older versions of YSQ (V1.0, V1.1, V1.2, and V1.3 Beta) are linked to in the readme for those that are interested in seeing what YSQ was like in past versions
- Lots of secrets to find
- Free novelty T-shirts with every download*

*T-shirt not included.

====Controls====
Since the player plays as Yoshi, Yoshi has some moves that Mario can't do (either because Yoshi is a Yoshi or because of the advancement of technology and game design (or something like that)). You will need to master these unique moves if you want to help Yoshi retrieve his stolen eggs!

A button - Aim eggs, Throw Eggs.
B button (in midair) - Flutter Jump (press B in midair again to do another Flutter Jump)
X button - Stick out tongue, spit out whatever is in Yoshi's mouth
Y button - Stick out tongue, spit out whatever is in Yoshi's mouth
Up + X or Y - Stick out tongue (upwards), spit out whatever is in Yoshi's mouth (upwards) 
Down (in midair) - Ground Pound
Up (holding it while aiming an egg) - Aim the egg straight up
Up (while standing next to someone) - Talk to certain NPCs 
R button (while in level) - lock/unlock targeting cursor when aiming an egg
R button (while on overworld) - Toggle between Hasty and Patient egg throwing styles
L button (while on overworld) - Bring up save prompt
Down (while aiming an egg) - cancel aiming an egg
Select (while on Overworld) - Bring up the status screen
Start (while a dialogue box is on screen) - Close dialogue box (Note: Some dialogue boxes can't be closed by pressing start)

Yoshi also possesses all the moves Mario has in the original SMW, except spin jumping, throwing fireballs, and flying with a cape.


====Notes====
- Press the L button while on the overworld to bring up the save prompt, so you can save your game.

- Unlike Mario, Yoshi can't spin Jump. The ground pound replaces the spin jump, though there are some things it can't do (like jumping off spiked enemies).

- Yoshi always runs. No need to hold the X or Y buttons to run.

- The counter on the lower left corner of the screen is your health counter. Every time Yoshi is hurt, this counter decreases by five. If the counter goes below 0, Yoshi will lose a life. Collect green coins (or stars that red eggs create when they hit an enemy) to refill the counter. Yoshi can have a maximum of 30 HP at once, allowing him to take up to 7 hits before dying (on normal mode, at least...).

- Speaking of green coins, you can collect them by either touching them, tossing an egg at them, or by hitting them with a shell.

- Yoshi is unable to grab most things with his hands. Instead, you must grab items, like springboards and shells with Yoshi's tongue.

- You can acquire eggs by eating enemies (though some can't be eaten, like Piranha Plants), and some can't be swallowed (like Koopa Shells) or picking them up off the ground (either out in the open, from an egg plant, or from a green spotted block).

- Yoshi can use three different kinds of eggs. Green eggs have no special properties. Yellow eggs create a coin when they hit an enemy. Red eggs create two stars that give Yoshi 1 HP each. 

- Whenever Yoshi gets an egg from one of the above methods, it will start to follow Yoshi from behind. This is how you can tell how many eggs Yoshi has. He can have up to six eggs following him at once.

- If you see cracked looking rocks, you can break them with ground pounds, throwing eggs at them, or hitting them from below.

- Yoshi loves green watermelons. Collect one of a 1-up.

- Whenever you press the R button while on the overworld, you'll change Yoshi's egg throwing style, which is determined by what sound you hear when you press the button. If you hear a fireball throwing sound, you switched it to "Hasty", but if you hear a coin sound, then you switched it to "Patient". With Patient, you have to press the A button twice to throw an egg; once to aim the egg, then again to throw. With Hasty, you have to press and hold the A button to aim, then release the A button to throw.

- With flutter jumping, it can be tricky to do at first. Here's how to do it properly. Whenever Yoshi finishes his current flutter jump, there is a short delay before he can do another flutter jump. Press and hold the jump button during this delay to ensure that Yoshi will flutter jump again once this delay is over. Practice this timing and you'll eventually be able to flutter jump like a pro.

- Experiment with how long you let Yoshi do a flutter jump for. There are various obstacles that can only be overcome by flutter jumping a certain way, such as using that slight boost Yoshi gets from the flutter jump to get around obstacles in areas where the ceiling is too low, or cancelling flutter jumps repeatedly to slow Yoshi's fall.

- If you've ever played Yoshi's Island before, then you should know that many of the strategies and tricks you used in that game will work in this game. However, some things work slightly different from YI, such as the flutter jumping, so keep that in mind.

- Some levels disable some of Yoshi's abilities, though it's usually justified in some way (ex. Yoshi enters an area that is very gross, causing him to lose his appetite, meaning Yoshi won't be able to use his tongue).

- Some characters that Yoshi encounters on his journey can be talked to by pressing up. Not everyone will want to talk to you, though.

- Every level, except for Yoshi's House, has a set of invisible 1-up checkpoints that will give you a 1-up if you find them. These are usually found in seemingly empty spots or in places that you'll most likely not go to normally. You're not required to find these for 100% completion (though if this game had achievements, this would probably be one of them), they're just an optional little secret for you to find, much like bonus rooms, scenario rooms, or error message rooms.

- Yoshi is a bit out of shape, thus he has a harder time flutter jumping compared to the average Yoshi. He can't get a boost from it at the peak of his jump, it can take him a while to rise up if he has a lot of downwards momentum, and since he has to make such an effort and focus to stay airborne, he loses his focus if he hits his head on the ceiling, requiring you to hit the button again to continue flutter jumping.

- You can re-enter destroyed switch palaces, castles, and fortresses the same way you normally enter levels.

- The L and R buttons are handy for those situations where you want to see farther ahead, such as a wide pit that you can't see the other side of when you're in the middle of the screen or to spot an enemy that may be a problem during a jump. You can also use Yoshi's flutter jump in a similar way, where you can jump to the side, then flutter jump back to the ledge you jumped from in order to scout out what's ahead before doing a tricky section.

- Sometimes, you'll need to think outside the box to get past something, to solve a puzzle, or to find a secret exit.

- Take your time when playing YSQ. YSQ's levels are generally designed in a way where rushing through them will likely result in Yoshi dying. With the exception of auto scrolling levels or the rare area with a time limit, most areas in YSQ have no time limit, so you have plenty of time to think things through about the current obstacle or puzzle before doing it.

- In order to advance beyond Yoshi's New Home at the start of the game, you must enter it twice (once, right after the intro and again after you've completed Yoshi's New House and you returned to the overworld). Then, you must exit out of Yoshi's New Home via side exits to go to the next level. If you think you are stuck on the overworld after beating Yoshi's New House once, then it is obvious that you didn't even read this readme.

- If you're an LPer who did a Let's Play of an older version of YSQ and are planning on LPing the newest version, I recommend that still show everything again. So much has changed in V1.3 over V1.2, even the stages that look almost the same as before may have a few new surprises or interesting changes.


====Special Stuff====

- Outside materials:
I made some extra materials for YSQ that should be in this .zip folder, since I wanted YSQ to feel more like a real SNES game and because I wanted YSQ to stand out among other SMW hacks. The .zip folder for this hack contains, besides the patch/game and this readme:

1). A box art drawing, which is a drawing I did myself that shows what the cover of the box might look like if YSQ actually came in a box.
Download Link: https://www.dropbox.com/s/1dig87wozi6fq87/YSQ%20Box%20Art.png?dl=0


2). A cartridge sticker image, which is meant to show what the cartridge sticker would look like. If you have a SNES flash cart or you are hardcore enough to actually put this game on a real SNES cartridge, you could print out this image and put it on the cartridge to make it feel more like YSQ is an actual SNES game. If you actually do this, then the dimensions of the sticker are: Width = 3.25 inches, Height = 1.75 inches (which is about 7.5% of the size of the image). In addition, you should fold the image about 0.25 inches from the top (which is where the top of the fat red line is at) as well as round out the corners. If you want to print it out, one way of doing so would be to open up Microsoft Word (if you have it), importing the sticker image into MS Word, shrinking the image to half its size in MS Word, setting the page size to 3.25 in. X 1.75 in., then printing it out. What you print out should be about the correct size, and its quality should be about the same as it was in MS Word.
Download Link: https://www.dropbox.com/s/32n2hpup6lfstca/YSQ%20Cartridge%20Sticker.png?dl=0


3). A game manual, which is written in a way you'd expect a game manual to be written. As in, it doesn't assume that you've played SMW before like this readme does. The reason that this readme is still included is because there might be some people who can't open .pdf files and this readme mentions things that would be kind of odd to mention in the manual, like the version history and glitches.
Download Link: https://www.dropbox.com/s/vy0mp9diu0hgbqs/YSQ%20Manual.pdf?dl=0


- Scenario rooms
Throughout the land of Weirdonia are what are called "Scenario Rooms" where the player is presented with a situation involving Yoshi in some way, and the player must pick from three choices, which represent what Yoshi can do for that given scenario. The choice you make in each one of these rooms determines what reward you get. Can you find all 10 of them?

- Yoshi Coins
Every level in YSQ has 5 Yoshi coins for you to collect. Each one is worth 20 coins, and if you collect all 5 in a level, you'll get an extra life. If you can collect every Yoshi coin in the game, then you'll be rewarded in some way that I'm going to keep a secret...

If you can do it without using cheats, savestates, rewinds, etc. (which I imagine is not how most people are going to do this. I dare you to prove me wrong), then you deserve some kind of medal for your amazing platforming skills!

Note: If you die before collecting all 5 Yoshi coins, then you'll lose the Yoshi coins you collected in that level, so be careful!

- Status Screen
Pressing start while you're on the overworld will bring up a status screen that keeps track of your progress through YSQ. This screen will tell you what levels you've been to, which exits you've triggered for those levels, and whether or not you got all 5 Yoshi coins in any level that has them. If you get 100% exits, then you can also use the status screen to warp to any level on the overworld at will, and if you get 100% of all the Yoshi coins, a Yoshi coin will appear on the status screen to indicate that you found them all (Note: This isn't the reward I mentioned in the Yoshi Coins entry above. Please don't send me angry messages about how you spent so much time and had so much trouble trying to get all the Yoshi coins and then thinking that the reward was just a Yoshi coin icon on the status screen. If you do this, then I have permission to laugh at you for not reading the readme. Don't give me a reason to laugh at you!)

- Hard mode
Whenever you go to select a file, you will have the option of selecting the difficulty level of YSQ. Normal mode is the standard difficulty, while Hard mode brings back the difficulty that V1.2 of YSQ had. Enabling hard mode will do the following:

1). Doubles Yoshi's knockback when he gets hit, up to V1.2 levels.
2). Increases the damage Yoshi takes from 5 to 10.
3). Caps the maximum health Yoshi can have to 20 instead of 30.
4). Midpoint tapes become useless (they'll still be present; they just won't do anything)
5). Starts you off with 2 lives instead of 5.
 
Are you hardcore enough to 100% the game in hard mode, especially without using cheats, savestates, rewinds, etc.?

- Boss Rush
If you get 100% of all the exits, this option will become available by hitting the green block in Yoshi's house. How fast you can beat each of the bosses in YSQ?

- Secret music house
Once you beat a certain level, this will become available to you by hitting the note block in Yoshi's house. Listen to all the songs in the game from the many talented music porters who did them.

- Error message rooms
These are simply rooms that either are caused by the player failing in an impossible or silly way, or they are rooms that Yoshifanatic forgot to test while he was making this hack, and thus, they decided to glitch out in bizarre ways while he wasn't looking. Can you find all 10 of these strange rooms?

- Replaying the Switch Palaces
Once you've beaten a switch palace, you'll be able to re-enter it just like any other level. Beating a switch palace a second time nets you a reward and is also required to get all Yoshi coins in each switch palace.

- The pink, red and yellow ? blocks in Yoshi's house.
What do these do? I'm not telling. If you reach certain points in YSQ, you'll unlock whatever function these blocks serve.


====Version History====
Updates in V1.0 (https://www.dropbox.com/s/p1hhvkggu5kzskp/YSQV1.0.zip?dl=0)
- What updates? This is the original version of YSQ.


Updates in V1.1 (https://www.dropbox.com/s/611etotv3lbhptg/YSQV1.1.zip?dl=0)
- There are three times more levels than in V1.0.
- I changed the song that plays in a few of the levels, as well as the song that plays on the cave submap on the overworld.
- Two of the Switch Palaces are now different colors.
- Some of the levels in world one have been moved somewhere else on the overworld.
- Some of the levels that were in V1.0 have a few secrets added to them. 
- The load times are a little shorter (not that they were long to begin with).
- During some cutscenes, I made it so that all sprite graphics are invisible, in order to prevent the player from seeing stuff that's not supposed to be visible.
- A couple of messages were added or changed slightly.
- One of the overworld paths was changed, because it caused Yoshi's position to be wrong on the overworld.
- I changed the graphics for most of the food items to make them look better.
- There are various minor improvements that don't really need to be listed individually.


Updates in V1.2 (https://www.dropbox.com/s/55hx3gfapwifxx5/YSQV1.2.zip?dl=0)
- The custom ASM has far fewer glitches with it, and has a few extra features.
- Many of the levels have been changed slightly to work better with the fixed ASM
- Midpoints have been added to many levels 
- I added an extra cutscene to one of the levels.
- A few more songs have been added to the game.
- I changed the "Yoshi Presents" sprite so that it looks completely different from the original "Nintendo Presents" sprite.
- I added a Credits sequence to the end of demo level
- When you enter a level, it now says "Yoshi Start!" instead of nothing.
- I fixed a glitch in Misty Mine, so that you won't be forced to die if you press down while in a barrel cannon. However, this means that you can no longer shoot straight down in them (not that you have to shoot in that direction, anyway)
- I made several minor adjustments that aren't worth mentioning.


Updates in V1.3 Beta (https://www.dropbox.com/s/1wr5bflw61e0xc0/YSQ%20V1.3Beta.zip?dl=0)
- There are twice as many levels as there were in V1.2, and several old levels have been lengthened or changed in some way.
- The game has been made easier in general, at least during normal mode...
- A new difficulty level has been added, which is hard.
- A status screen has been added to the overworld, so you can keep track of your progress throughout the game.
- Midpoints have been added to most levels that didn't have them before.
- Many more songs have been added to YSQ. This includes a new death and game over theme, as well as a victory theme when you complete a level.
- Some areas now play different music, such as the title screen.
- Layer 3 water is now transparent.
- The blue bars that are a part of the water effect HDMA used in some levels are no longer there, in order to fix a glitch where those bars would appear for a second while transitioning to another level.
- I fixed a serious bug where, if you are playing YSQ in BSNES Accuracy mode or on a real SNES, certain message spites might not display the message they were supposed to.
- A few levels have been moved elsewhere on the overworld, merged with another level, or had their level design changed.
- I fixed a lot of bugs with the Yoshi Player patch, such as the glitch where the green coins didn't always give you health when picked up, the glitch where Yoshi's tongue would get stopped by or stuck on certain things for no reason, the glitch where Yoshi can continue ground pounding through spiked enemies, etc.
- I've made various graphical and palette edits to improve the graphics.
- I fixed the glitches with certain custom sprites, like the barrel cannon, the soda bottle, and the World 2 boss.
- The two known cases where a static sound would play at the start of a song have been fixed.
- I've switched to a new message format that enhances all the text in this hack immensely. Every scenario room and most of the cutscenes are now in this format.
- You can no longer see what Yoshi is thinking about during the castle cutscenes, due to the new way the cutscenes are presented. However, most of the things Yoshi was thinking about during those cutscenes are now a part of his dialogue in those cutscenes.
- Yoshi's New Home now serves as a hub, where you can access various stuff. More stuff is unlocked as you progress in the hack.
- The intro gives more details about the story, and it is now an actual level.
- I've written a tutorial, which is accessed from Yoshi's New Home, telling you how Yoshi's unique moves work.
- The switch palace room in Yoshi's New Home has been dummied out, because switch palaces can now be re-entered from the overworld
- You can now save the game at any time by pressing the L button on the overworld.
- A few extra features have been added to the Yoshi Player patch, such as randomized idle animations and the patient/hasty egg throwing style setting.
- Some levels now have a parallax scrolling HDMA effect.
- Most underwater areas now have a blue (or another color in some cases) tint to them, to make those areas look more like they are underwater.
- The Yoshis in Yoshi Woods have more animations and you can now talk to them.
- Bonus rooms have been added to a few more levels.
- I fixed a strange glitch where Yoshi would sometimes start at the midpoint of levels he'd never been to before, particularly S.S.Sunk.
- The P-switch theme has been removed, in order to fix a few music glitches caused by having sampled death and victory themes.


Updates in V1.3 (Find it on SMWCentral's hack section)
- Balanced the difficulty better so certain really hard sections are easier.
- Custom Layer 3 images have been added to some areas to make them look nicer.
- Cyan Yoshi and Aero have been added to the game.
- Reworded a few parts of some messages to make certain things clearer to the player.
- Removed the layer 2 smashers and lava from the World 6 boss's arena and redesigned it to make up for that change. This was done to reduce slowdown.
- Potentially fixed a bug where the game freezes after completing the puzzle in the world 6 castle on rare occasions (Not sure if this is truly fixed because I couldn't replicate it after one of my beta testers reported it).
- Modified the health counter number graphics to make them easier to see in some areas.
- Added idle animations to the few characters that were lacking one and gave one of those characters dialog if you decide to talk to him.
- Fixed a bunch of typos in various messages.
- Added the names of the people who helped beta test YSQ to the credits.
- Added a few anti-cheat measures to prevent cheating (only a few. Most of the ones you may encounter are actually unintentional, as a side effect to the way YSQ was designed and how YSQ changes SMW's engine).
- Removed the ? clouds because they refuse to work half the time, and I have absolutely no idea how to fix them.
- Made a bunch of minor changes and bug fixes that aren't too major.


====Glitches====
- There are possibly some spots where, depending on how many eggs Yoshi has following him, the game may slow down. It was very hard to avoid that at times, but at least it won't last too long if it does happen.
- Some levels may have some minor sound glitches in them, due to the use of sample banks, echo, or AddmusicK.
- Some doors/pipes/teleport blocks take the game a bit longer to load the level they take you to. This is not really a glitch (as it's intentional, so that layer 2 in certain levels is placed right), but I figured I'd mention this.
- In some places, I used layer 3 in a level that has a message box. However, layer 3 does come back after the message ends, so this isn't really an issue.
- Any time the game switches between songs (with one or two exceptions) there is a one second pause. In addition, sometimes the status bar will be in a different position during that one second on occasion. This is more of a limitation of the new music engine introduced with AddmusicK than a glitch, but I should mention this anyway. Besides, this lets me switch the sample bank mid-level for the songs that use a different sample bank than the one currently loaded, since the sample banks are loaded with the song, rather than loaded with the level.
- You can only cancel a dialogue box when text is being drawn in the text box, not when it's waiting for you to press A or when it's paused for a bit.
- In reverse gravity (aka when Yoshi is upside down relative to the enemies), Yoshi is unable to stick his tongue out and egg aiming is reversed (so, holding up will result in Yoshi aiming down).
- Every once in a while when you bring up the status screen, the game might get stuck on the black screen, which I have absolutely no idea why this happens. If this happens, you'll need to reset the game. I HIGHLY urge you to save your game before bringing up the status screen just in case so you don't lose any progress (thankfully, YSQ saves more things than just the events you've triggered. It also saves things like your coin count, lives, which levels you got every Yoshi coin in, etc, so it's almost like loading a savestate when you reload the game normally).
- YSQ made quite a few changes to SMW's engine and has so much stuff crammed into 4 MB of space, that I wouldn't be surprised if a few strange bugs pop up if you use cheats or try to modify YSQ in Lunar Magic, even if you use Version 2.30. Do not modify YSQ or use cheats, or else you may screw something up!


====QPMAMASPTIWAHFYC (Questions People Might Ask Me At Some Point That I Will Answer Here For Your Convenience)====

- Q: "What do I need to do to start playing your hack?"
	
  A: First, go download a patching program that lets you patch an IPS patch to a ROM, such as Lunar IPS or FLIPS (you can find the former on the creator of Lunar Magic's site (Fusoya) and the latter on SMWCentral.net. Alternatively, you can download the latest version of Lunar Magic which has the ability to apply an IPS patch to SMW. Next, go download a copy of the U.S. version of a headered SMW ROM (don't ask me where to find them though, cause I can't help you with that, though I will tell you that you should look for one with [!] in its name to ensure that you got a good copy, as well as [U], which means that it's the U.S. version of SMW). Next, go download your SNES emulator of choice (or buy an SNES flash cart if you have an SNES and a lot of money) and start playing the game after you apply the IPS patch to the SMW ROM.

- Q: "Why do most of the Yoshis in this game talk in third person?"

  A: That was something that I was inspired to do based on how Yoshi talked in the Super Mario World cartoon, which I thought was kind of cute. Fortunately, if you pay attention to the context of the Yoshis' dialog, it shouldn't be too hard to tell if they are referring to themselves or others when they say Yoshi. As for the Yoshis that don't talk in third person, there actually is an in-game explanation for that if you talk to one of the Yoshis that doesn't speak in third person twice (although the real life explanation for that would be that those Yoshis are either special cases or they are my friends' characters, so they are going to talk the way they are supposed to talk).

- Q: "Aaargghhh!! This jump/puzzle is impossible! How are you supposed to get past this?"

  A: Nothing is impossible in YSQ (assuming you're doing things correctly of course).  This hack has been tested by me multiple times (both on a real SNES and an emulator) and by several others, so you should try to tackle the part you're struggling in YSQ in a different way (such as varying the way Yoshi is flutter jumping through an obstacle). If all else fails, search up a video of someone playing YSQ on that part and see how they got past it, or just message me and I'll help out.

- Q: "Did you code a lot of this stuff yourself?"

  A: Most of the custom ASM in YSQ was done by others (for example, the Yoshi ASM that gives the player character all of Yoshi's moves from Yoshi's Island was done by Jimmy52905 on SMWCentral), so no. That said, there are some things I coded myself, mainly a few simple custom blocks, a couple simple sprites (like the Yoshi sprite on the lower right corner of the titlescreen), and one of the bosses. Plus, while the Yoshi ASM wasn't done by me, I did add a few extra things to it that were not in the ASM patch originally, such as the randomized idle animation, the patient/hasty egg throw option, and many bug fixes to it.

- Q: "Can I use the graphics you used in YSQ?"

  A: Yes. You're free to use whatever graphics you want in YSQ, except for the Yoshi OC sprites. You'll need my permission to use mine or my friends' permission to use theirs. Also, I released a bunch of graphics I ripped/drew for YSQ already, so you ought to take a look at SMWCentral's graphics section to see if what you want to use has been released (the advantage of this being that I made those graphics submissions are easier to use than if you were to take them out of YSQ, since YSQ's ExGFX and Map16 organization is haphazard at best).

- Q: "I can't find this secret exit. Where is it?"

  A: Quite a few of the secret exits in YSQ are pretty deviously hidden, so don't give up if you can't seem to find it. If all else fails, go watch a video of someone playing that level you can't find the secret exit in, or just message me and I'll help out.

- Q: "What is the point of the Yoshi coins?"

  A: They are meant to be a challenge for those that want to 100% YSQ. Plus, there is a reward for finding them all, but it's a secret.

- Q: "Can I use YSQ as a base for my hack?"

  A: I'd be ok with that, but I highly don't recommend it. You'd potentially encounter lots of glitches due to the ASM changes I've done to YSQ, and you'd have absolutely no idea what most of those changes even are or where I applied them. All in all, it's not worth it.

- Q: "What is the meaning of life?"

- A: That question has nothing to do with YSQ, but I'll answer it anyway. The meaning of life is to put meaning into your life.

====Misc.====
- If you have any comments about this hack, post them in the "Yoshi's Strange Quest" thread on Super Mario World Central or message him on any of the sites he has an account on (besides the SMWiki). You can find him at these places:
	- SMWCentral (Yoshifanatic): http://www.smwcentral.net/?p=profile&id=13743
	- Youtube (yoshifanatic1): http://www.youtube.com/user/Yoshifanatic1
	- deviantART (BiggestYoshifan): http://biggestyoshifan.deviantart.com/
	- FurAffinity (BiggestYoshifan): http://www.furaffinity.net/user/biggestyoshifan/

- This is the final version of YSQ, unless I have to submit new version that fixes any glitches me or the playtesters didn't notice (particularly if they are major glitches).

- Oh, and thanks for downloading my hack! Hope you enjoy it as much as I enjoyed making it! ^_^