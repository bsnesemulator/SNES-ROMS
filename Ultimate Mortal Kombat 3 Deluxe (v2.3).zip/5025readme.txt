Ultimate Mortal Kombat 3 Deluxe 2.2

Sheeva finally playable (with Vs. Screen and finishers)!
11 arenas in total - (9 MK3 arenas recovered, with Pit Fatalities)!
Animalities! [Only works on "one button finishers"]
Rain and Noob Saibot are now available for battle in the towers!
Now with The Graveyard arena!
Prototype of the arena "Goro's Lair".
Rain has a Fatality! (commands same as MK Trilogy)
Noob Saibot has a Fatality! (commands same as MK Trilogy)
3x3 mode!
More characters run in Strykerâ€™s Friendship
Infinite time for the Kombat Zone[/li]
Now the name â€œFriendshipâ€ is spoken twice, as in MK3!
Mortal Kombat Trilogy sound effects!
Shang Tsung now turns into Smoke! [Hold X, Left, Left, Forward, release X]
Menu codes in just one button!
The Rooftop, The Street, The Subway and Bell Tower stages now have the screen completely filled (without the limitation of the â€œblack barâ€ on the floor).
Animation when the Round starts in â€œThe Portalâ€

Video: https://www.youtube.com/watch?v=AhTVc2gxn8I

List of Idels/Chameleon moves and powers: https://www.youtube.com/watch?v=uE2Jijsqvvs&t=51s